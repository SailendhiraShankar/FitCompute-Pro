<?php
$db=new mysqli("localhost","root","","pro");
?>